import tkinter as tk

####################################
def imagebutton():
    print("이미지버튼입니다!")
def checks():
    if(var.get()==0):
        print("체크해제!")
    elif(var.get()==1):
        print("체크!")
####################################

root = tk.Tk()
root.title("분노의 버튼누르기!!")

tk.Label(text="안녕하세요 이거슨 텍스트입니다"
         ,fg="red",font="Times").pack(anchor=tk.W)
frame1 = tk.Frame(root).pack(side="top")
frame2 = tk.Frame(root).pack(side="top")
frame3 = tk.Frame(root).pack(side="top")
images = tk.PhotoImage(file="C:\\Users\\sw031\\OneDrive\\바탕 화면\\새 폴더\\hmm.gif")
var = tk.IntVar()

tk.Button(frame1,text="일반버튼인데요?"
          ,fg="green").pack(side="top")
tk.Button(frame2,image=images,command=imagebutton).pack(side="top")
tk.Checkbutton(frame3,indicatoron=1,text="체크버튼입니다!",variable=var,command=checks).pack(side="bottom")

root.mainloop()
